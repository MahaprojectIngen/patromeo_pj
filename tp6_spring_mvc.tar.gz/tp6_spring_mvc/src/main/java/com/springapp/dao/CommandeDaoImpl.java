package com.springapp.dao;

import com.springapp.beans.Commande;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.springapp.dao.DAOUtilitaire.fermeturesSilencieuses;
import static com.springapp.dao.DAOUtilitaire.initialisationRequetePreparee;


/**
 * Created by patrick on 2017/09/10.
 */
@Service
public class CommandeDaoImpl implements CommandeDao {
    private  final String  getSQL_SELECT = SQL_SELECT;
    private static final String SQL_SELECT_PAR_ID = "SELECT id, id_client, date, montant, mode_paiement, statut_paiement, mode_livraison, statut_livraison FROM Commande WHERE id = ?";
    private static final String SQL_INSERT = "INSERT INTO Commande (id_client, date, montant, mode_paiement, statut_paiement, mode_livraison, statut_livraison) VALUES (?, ?, ? , ?, ?, ?, ?)";
    private static final String SQL_DELETE_PAR_ID = "DELETE FROM Commande WHERE id = ?";
    private  static  final  String SQL_SELECT = "SELECT id, id_client, date, montant, mode_paiement, statut_paiement, mode_livraison, statut_livraison FROM Commande ORDER BY id_client";
    private static final String SQL_SELECT_BY = "SELECT id, id_client, date, montant, mode_paiement, statut_paiement, mode_livraison, statut_livraison FROM Commande";

    @Autowired
    private DAOFactory daoFactory;

    @Autowired
    private ClientDao  clientDao;

    public  CommandeDaoImpl(){

    }

    public CommandeDaoImpl( DAOFactory daoFactory ) {
        this.daoFactory = daoFactory;
    }
    /* Implémentation de la méthode définie dans l'interface
    CommandeDao */
    @Override
    public Commande trouver(long id) throws DAOException {
        return trouver(SQL_SELECT_PAR_ID, id );
    }

    private Commande trouver(String sqlSelectParId, Object...objets) {
        Connection connexion = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Commande commande = null;
        try {
        /* Récupération d'une connexion depuis la Factory */
            connexion = daoFactory.getConnection();
        /*
         * Préparation de la requête avec les objets passés en arguments
         * (ici, uniquement un id) et exécution.
         */
            preparedStatement = initialisationRequetePreparee(
                    connexion, sqlSelectParId, false, objets );
            resultSet = preparedStatement.executeQuery();
/* Parcours de la ligne de données retournée dans le
ResultSet */
            if ( resultSet.next() ) {
                commande = map( resultSet );
            }
        } catch ( SQLException e ) {
            throw new DAOException( e );
        } finally {
            fermeturesSilencieuses( resultSet, preparedStatement,
                    connexion );
        }
        return commande;
    }


    /* Implémentation de la méthode définie dans l'interface
    CommandeDao */

    @Override
    public void creer(Commande commande) throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet valeursAutoGenerees = null;
        try {
            connection = daoFactory.getConnection();
            preparedStatement = initialisationRequetePreparee(
                    connection, SQL_INSERT, true,
                    commande.getClient().getId(),
                           Date.valueOf(commande.getDate()),
                    commande.getMontant(),
                    commande.getModePaiement(),
                    commande.getStatutPaiement(),
                    commande.getModeLivraison(),
                    commande.getStatutLivraison() );
            int statut = preparedStatement.executeUpdate();
            if ( statut == 0 ) {
                throw new DAOException("Échec de la création de  la commande, aucune ligne ajoutée dans la table." );
            }
            valeursAutoGenerees =
                    preparedStatement.getGeneratedKeys();
            if ( valeursAutoGenerees.next() ) {
                commande.setId( valeursAutoGenerees.getLong( 1 )
                );
            } else {
                throw new DAOException( "Échec de la création de la commande en base, aucun ID auto-généré retourné." );
            }
        } catch ( SQLException e ) {
            throw new DAOException( e );
        } finally {
            fermeturesSilencieuses( valeursAutoGenerees,preparedStatement, connection );
        }
    }

    @Override
    public List<Commande> lister() throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Commande> commandes = new ArrayList<Commande>();
        try {
            connection = daoFactory.getConnection();
            preparedStatement = connection.prepareStatement(getSQL_SELECT);
            resultSet = preparedStatement.executeQuery();
            while ( resultSet.next() ) {
                try {
                    commandes.add(map(resultSet));
                }catch (SQLException e){
                    e.getSQLState();
                }
            }
        } catch ( SQLException e ) {
            throw new DAOException( e );
        } finally {
            fermeturesSilencieuses( resultSet, preparedStatement,
                    connection );
        }
    return commandes;
}

    private Commande map(ResultSet resultSet) throws SQLException {
        Commande commande = new Commande();
        commande.setId( resultSet.getLong( "id" ) );
/*
* Petit changement ici : pour récupérer un client, il nous faut
faire
* appel à la méthode trouver() du DAO Client, afin de récupérer
un bean
* Client à partir de l'id présent dans la table Commande.
*/
        ClientDao clientDao = daoFactory.getClientDao();

      //  try {
        String date = resultSet.getString("date");
        date = date.substring(0, date.indexOf(" "));
        commande.setDate(LocalDate.parse(date));
       // }catch (Exception  e){
       //     e.getLocalizedMessage();
      //  }
        commande.setMontant(resultSet.getDouble("montant"));
        commande.setModePaiement( resultSet.getString("mode_paiement" ) );
        commande.setStatutPaiement( resultSet.getString("statut_paiement" ) );
        commande.setModeLivraison( resultSet.getString("mode_livraison" ) );
        commande.setStatutLivraison( resultSet.getString("statut_livraison" ) );
        commande.setClient(clientDao.find(resultSet.getLong("id_client")));
        return commande;
    }


    @Override
    public void supprimer(Commande commande) throws DAOException {
        Connection connexion = null;
        PreparedStatement preparedStatement = null;
        try {
            connexion = daoFactory.getConnection();
            preparedStatement = initialisationRequetePreparee( connexion, SQL_DELETE_PAR_ID, true, commande.getId() );
            int statut = preparedStatement.executeUpdate();
            if ( statut == 0 ) {
                throw new DAOException( "Échec de la suppression  de la commande, aucune ligne supprimée de la table." );
            } else {
                commande.setId( null );
            }
        } catch ( SQLException e ) {
            throw new DAOException( e );
        } finally {
            fermeturesSilencieuses( preparedStatement, connexion
            );
        }

    }

    @Override
    public List<Commande> findAll() throws DAOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        List<Commande> commandes = new ArrayList<Commande>();
        try {
            connection = daoFactory.getConnection();
            preparedStatement = connection.prepareStatement(SQL_SELECT_BY);
            resultSet = preparedStatement.executeQuery();
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                commandes.add(map(resultSet));
            }
        } catch (SQLException e) {
            throw new DAOException(e);
        } finally {
            fermeturesSilencieuses(resultSet, preparedStatement,
                    connection);
        }
        return commandes;
    }
}
