package com.springapp.beans;

import com.springapp.validator.FileSize;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import java.io.Serializable;

/**
 * Created by patrick on 2017/08/27.
 */
public class Client implements Serializable {

    private Long    id;
    @NotNull
    @Size(message="Please\tenter\ta\tcustomer\tname", min = 3, max=30)
    private String  nom;

    @Size(message = "Please\tenter\ta\tlastname", min = 3, max = 30)
    private String  prenom;

    @Size(message ="Please\tenter\tan  address", min = 3, max = 60)
    private String  adresse;

    @Size(message = "Please\tensure\tthe\ttelephone number\tis\tcorrect", min = 3, max = 60)
    @Pattern(regexp = "^\\d+$")
    private String  telephone;

    @Email
    @NotNull
    @Pattern(message = "Invalid\temail", regexp = "([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)")
    private String  email;

    @FileSize(max = 100000)
    private MultipartFile images;

    private String  nomImage;

    public Client(){

    }

    public Client(String nom, String prenom, String adresse, String telephone, String  email, MultipartFile images){
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
        this.telephone = telephone;
        this.email = email;
        this.images = images;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public MultipartFile getImages() {
        return images;
    }

    public void setImages(MultipartFile images) {
        this.images = images;
    }

    public String getNomImage() {
        return nomImage;
    }

    public void setNomImage(String nomImage) {
        this.nomImage = nomImage;
    }
}
