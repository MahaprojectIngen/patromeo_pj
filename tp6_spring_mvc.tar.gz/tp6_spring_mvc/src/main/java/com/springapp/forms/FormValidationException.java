package com.springapp.forms;

/**
 * Created by patrick on 2017/08/28.
 */
public class FormValidationException extends Exception {

    public FormValidationException(String message){
        super(message);
    }
}
