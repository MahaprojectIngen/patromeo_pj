package com.springapp.dao;

import com.springapp.beans.Client;
import com.springapp.beans.Client;

import java.util.List;

/**
 * Created by patrick on 2017/08/27.
 */
public interface ClientDao {
     void  creer(Client client, String imageurl) throws DAOException;

     Client trouver(String  email) throws DAOException;

     Client find(long id) throws DAOException;

     List<Client>  lister() throws DAOException;

     void  supprimer(Client client) throws DAOException;

}
