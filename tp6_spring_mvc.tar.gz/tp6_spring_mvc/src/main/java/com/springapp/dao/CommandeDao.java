package com.springapp.dao;

import com.springapp.beans.Commande;

import java.util.List;

/**
 * Created by patrick on 2017/08/27.
 */
public interface CommandeDao {
    void creer(Commande commande) throws DAOException;

    Commande trouver(long id) throws DAOException;

    List<Commande>  lister() throws DAOException;

    void  supprimer(Commande commande) throws DAOException;

    List<Commande>  findAll() throws DAOException;
}
