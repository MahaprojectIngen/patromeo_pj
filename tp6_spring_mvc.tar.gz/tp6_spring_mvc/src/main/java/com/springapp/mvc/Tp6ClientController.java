package com.springapp.mvc;

import com.springapp.beans.Client;
import com.springapp.dao.ClientDao;
import com.springapp.dao.DAOException;
import com.springapp.forms.FormValidationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.HttpServletBean;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.*;
import java.util.*;

@Controller
@RequestMapping("/")
public class Tp6ClientController extends HttpServletBean {
    private Log log = LogFactory.getLog(Tp6ClientController.class);


    @Autowired
    private ClientDao clientDao;


    @RequestMapping(method = RequestMethod.GET)
    public String printWelcome(ModelMap model) {
        model.addAttribute("message", "Hello world!");
        return "hello";
    }

    @RequestMapping(value = "/creationClient")
    public String creationClient(Model model) {
        log.debug("creation client call");
        model.addAttribute("client", new Client());
        return "creerClient";
    }

    @RequestMapping(value = "/afficherClient")
    public String afficherClient(@Valid @ModelAttribute(value = "client") Client client, BindingResult bindingResult, @RequestParam(value = "email", required = true) String email_, HttpServletRequest httpServletRequest, Model model) throws ServletException, IOException, FormValidationException, IllegalAccessException, InstantiationException {
        log.debug("liste client call");
        boolean hasEmail = email_ != "" && clientDao.trouver(email_) != null;
        System.out.println("email found value :" + email_ + " dans la base : " + hasEmail);
        MultipartFile files = client.getImages();
        List<String> fileNames = new ArrayList<String>();
        HttpSession session = httpServletRequest.getSession();
        Map<Long, Client> clients = (HashMap<Long, Client>) session.getAttribute("clients");
        String imageurl = validationImages(files, fileNames, httpServletRequest, client, session);
        if(imageurl != null){
            client.setNomImage(imageurl);
        }
        /*Gestion des erreurs dans le formulaire*/
        FieldError fieldError = null;
        boolean email_field_errors = bindingResult.hasFieldErrors("email");
        // clientValidation(bindingResult, email_field_errors, email_, clientDao, fieldError);
        if (bindingResult.hasErrors()) {
            if (hasEmail) {
                fieldError = bindingResult.getFieldError();
                String message = "cette addresse email est déjà utilisée, merci de choisir une autre";
                log.info("Code: " + fieldError.getCode() + ", object:"
                        + fieldError.getObjectName() + ", field: "
                        + fieldError.getField());

                String email = "email";
                bindingResult.reject("code", "" + message + "");
                return "creerClient";
            }
            fieldError = bindingResult.getFieldError();
            log.info("Code: " + fieldError.getCode() + ", object:"
                    + fieldError.getObjectName() + ", field: "
                    + fieldError.getField());
            return "creerClient";
        } else if (!(bindingResult.hasErrors()) && (email_ != "" && clientDao.trouver(email_) != null)) {

            String message = "cette addresse email est déjà utilisée, merci de choisir une autre";
            fieldError = bindingResult.getFieldError();
            String email = "email";
            bindingResult.reject("code", "" + message + "");
            return "creerClient";
        }

        if (clients == null) {
            List<Client> listeClients = clientDao.lister();
            clients = new HashMap<Long, Client>();
            String images_url = null;
            for (Client client1 : listeClients) {
                images_url = client1.getNomImage();
                client1.setNomImage(images_url);
                MultipartFile  multipartFile = client.getImages();
                System.out.println("multipart file image:" + multipartFile);
                String image_nom_session = multipartFile.getName();
                if( images_url != null){
                    client1.setNomImage(images_url);
                }
                clients.put(client1.getId(), client1);
            }
            session.setAttribute("clients", clients);
            session.setAttribute("image_names", images_url);
        }
        /*insertion des information concernants le client dans la base après validation*/
        clientDao.creer(client, imageurl);

        /*ajout des données clients dans le bean client*/
        client.setNom(client.getNom());
        client.setPrenom(client.getPrenom());
        client.setAdresse(client.getAdresse());
        client.setTelephone(client.getTelephone());
        client.setEmail(client.getEmail());
        client.setImages(client.getImages());
        client.setNomImage(client.getNomImage());
        /**/

        /* Puis ajout du client courant dans la map */
        clients.put(client.getId(), client);

         /* Et enfin (ré)enregistrement de la map en session */
        session.setAttribute("clients", clients);
        //model.addAttribute("clients", clients);

        model.addAttribute("client", client);
        System.out.println("email value: " + email_);
        return "afficherClient";
    }

    protected boolean clientValidation(BindingResult bindingResult, boolean email_field_errors, String email_, ClientDao clientDao, FieldError fieldError) {

        if (bindingResult.hasErrors()) {
            fieldError = bindingResult.getFieldError();
            log.info("Code: " + fieldError.getCode() + ", object:"
                    + fieldError.getObjectName() + ", field: "
                    + fieldError.getField());
            return true;
        } else if (bindingResult.hasErrors()) {
            if (email_ != "" && clientDao.trouver(email_) != null) {
                fieldError = bindingResult.getFieldError();
                String message = "cette addresse email est déjà utilisée, merci de choisir une autre";
                log.info("Code: " + fieldError.getCode() + ", object:"
                        + fieldError.getObjectName() + ", field: "
                        + fieldError.getField());

                String email = "email";
                bindingResult.reject("code", "" + message + "");
            }
            fieldError = bindingResult.getFieldError();
            log.info("Code: " + fieldError.getCode() + ", object:"
                    + fieldError.getObjectName() + ", field: "
                    + fieldError.getField());
            return true;
        } else if (!(bindingResult.hasErrors()) && (email_ != "" && clientDao.trouver(email_) != null)) {

            String message = "cette addresse email est déjà utilisée, merci de choisir une autre";
            fieldError = bindingResult.getFieldError();
            String email = "email";
            bindingResult.reject("code", "" + message + "");
            return true;
        }
        return false;
    }

    protected String validationImages(MultipartFile files, List<String> fileNames, HttpServletRequest httpServletRequest, Client client, HttpSession  httpSession) throws IOException {
        String fileName = "";
        if (files != null && files.getSize() > 0) {
            fileName = files.getOriginalFilename();
            fileNames.add(fileName);
            InputStream  inputStream = null;
            OutputStream  outputStream = null;
            int longueur = 0;
            File imageFile = new File(httpServletRequest.getServletContext().getRealPath("/image"),fileName);
            try {
                files.transferTo(imageFile);
                fileNames.add(fileName);
            } catch (IOException e) {
                e.printStackTrace();
            }
            client.setImages(files);
            return  fileName;
        }
        return  fileName;
    }


    @RequestMapping(value = "/listerClient")
    public String listerClients(HttpServletRequest httpServletRequest, Model model) {

        return "listerClient";
    }

    @RequestMapping(value = "/suppressionClient")
    public String suppressionClient(HttpServletRequest httpServletRequest, Model model) {
        HttpSession session = httpServletRequest.getSession();
        Map<Long, Client> clients = (HashMap<Long, Client>) session.getAttribute("clients");
        String idClient = httpServletRequest.getParameter("id");
        Long id = null;
        try {
            id = Long.parseLong(idClient);
        } catch (Exception e) {
            e.getLocalizedMessage();
        }
        //if (clients != null && clientDao.trouver(clients.get(id).getEmail()) != null) {
            //for(Map.Entry<Long, Client> clientHashMap : clients.entrySet()) {
            // id = clientHashMap.getKey();
            System.out.println("id value: " + id + " valid value :" +(clients != null && clientDao.trouver(clients.get(id).getEmail()) != null ));
            try {
                if (clients != null && clientDao.trouver(clients.get(id).getEmail()) != null) {
                         /*Alors suppression du client de la BDD */
                    clientDao.supprimer(clients.get(id));
                    /*Puis suppression du client de la Map */
                    clients.remove(id);
                }else {
                    return "listerClient";
                }

            } catch (DAOException e) {
                e.printStackTrace();
            }
            /*Remplacement de l'ancienne Map en session par la nouvelle*/
            session.setAttribute("clients", clients);
            model.addAttribute("clients", clients);

            return "redirect:/listerClient";

    }

    @RequestMapping(value = "/image")
    public String  image(HttpServletRequest httpServletRequest, Model model){
        HttpSession session = httpServletRequest.getSession();
        Map<Long, Client> clients = (HashMap<Long, Client>) session.getAttribute("clients");
        String idClient = httpServletRequest.getParameter("id");
        if (clients != null ){
            Long id = null;
            try {
                id = Long.parseLong(idClient);
            } catch (Exception e) {
                e.getLocalizedMessage();
            }
            Client client = clients.get(id);

            model.addAttribute("client", client);
            return "afficherImage";
        }
        return "afficherImage";
    }
}
