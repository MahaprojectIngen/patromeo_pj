package com.springapp.validator;

import com.springapp.constraintValidator.FileSizeValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;
import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;


/**
 * Created by patrick on 2017/10/09.
 */
@Documented
@Constraint(validatedBy = FileSizeValidator.class)
@Target( { ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface FileSize {
    String message() default "Invalid file size, maximum size required is: 100000 bytes ";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};


    /**
     * @return size the file size in bytes must be lower or equal to
     */
    long max() default Long.MAX_VALUE;

    /**
     * Defines several {@link FileSize} annotations on the same element.
     *
     * @see FileSize
     */
    @Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
    @Retention(RUNTIME)
    @Documented
    @interface List {
        FileSize[] value();
    }
}
