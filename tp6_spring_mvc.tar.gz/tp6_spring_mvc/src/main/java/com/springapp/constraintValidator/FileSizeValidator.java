package com.springapp.constraintValidator;

import com.springapp.validator.FileSize;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Created by patrick on 2017/10/09.
 */
public class FileSizeValidator implements ConstraintValidator<FileSize, MultipartFile> {
    private long max;

    @Override
    public void initialize(FileSize constraintAnnotation) {
        max = constraintAnnotation.max();
    }

    @Override
    public boolean isValid(MultipartFile multipartFile, ConstraintValidatorContext constraintValidatorContext) {
        if (multipartFile == null || multipartFile.isEmpty()) {
            return true;

        }
        long size = multipartFile.getSize();
        return size <= max;
    }
}
