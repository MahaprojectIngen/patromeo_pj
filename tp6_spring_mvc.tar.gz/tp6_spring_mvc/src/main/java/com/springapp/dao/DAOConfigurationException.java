package com.springapp.dao;

/**
 * Created by patrick on 2017/08/26.
 */
public class DAOConfigurationException extends RuntimeException{
    /*
    Constructeurs
     */
    public DAOConfigurationException(String message){
        super(message);
    }

    public DAOConfigurationException(String  message, Throwable cause){
        super(message, cause);
    }

    public DAOConfigurationException(Throwable cause){
        super(cause);
    }
}
