package com.springapp.beans;


import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * Created by patrick on 2017/08/27.
 */
public class Commande implements Serializable{

    private Long id;


    private @NotNull LocalDate date;

    @NotNull
    @Digits(integer = 5, fraction = 2)
    private Double montant;

    @NotNull
    @Size(min = 8)
    private String modePaiement;

    @NotNull
    @Size(min = 8)
    private String statutPaiement;

    @NotNull
    @Size(min = 8)
    private String modeLivraison;

    @NotNull
    @Size(min = 8)
    private String statutLivraison;


    @NotNull
    @Valid
    private Client  client = new Client();

    public Commande(){

    }

    public Commande(Client client, Double montant,  String modePaiement, String statutPaiement, String modeLivraison
    , String  statutLivraison){
        this.client = client;
        this.montant= montant;
        this.modePaiement = modePaiement;
        this.statutPaiement = statutPaiement;
        this.modeLivraison = modeLivraison;
        this.statutLivraison = statutLivraison;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public @NotNull LocalDate getDate() {
        return date;
    }

    public void setDate(@NotNull LocalDate date) {
        this.date = date;
    }

    public Double getMontant() {
        return montant;
    }

    public void setMontant(Double montant) {
        this.montant = montant;
    }

    public String getModePaiement() {
        return modePaiement;
    }

    public void setModePaiement(String modePaiement) {
        this.modePaiement = modePaiement;
    }

    public String getStatutPaiement() {
        return statutPaiement;
    }

    public void setStatutPaiement(String statutPaiement) {
        this.statutPaiement = statutPaiement;
    }

    public String getModeLivraison() {
        return modeLivraison;
    }

    public void setModeLivraison(String modeLivraison) {
        this.modeLivraison = modeLivraison;
    }

    public String getStatutLivraison() {
        return statutLivraison;
    }

    public void setStatutLivraison(String statuLivraison) {
        this.statutLivraison = statuLivraison;
    }
}
