package com.springapp.config;

import com.springapp.dao.DAOFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Created by patrick on 2017/08/26.
 */
public class InitialisationDaoFactory implements ServletContextListener{

    private static final String ATT_DAO_FACTORY = "daofactory";

    @Autowired
    private DAOFactory daoFactory;

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
          /* Récupération du ServletContext lors du chargement de
l'application */
        ServletContext servletContext = servletContextEvent.getServletContext();
/* Instanciation de notre DAOFactory */
        this.daoFactory = DAOFactory.getInstance();
/* Enregistrement dans un attribut ayant pour portée toute
l'application */
        servletContext.setAttribute( ATT_DAO_FACTORY,
                this.daoFactory );
    }



    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }
}
