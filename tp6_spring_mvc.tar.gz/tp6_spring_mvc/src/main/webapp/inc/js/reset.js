$(document).ready(function(){
  $("#form").click(function(){
/* single line Reset function executes on click of Reset Button*/
    $("form")[0].reset();
  });
 
});
